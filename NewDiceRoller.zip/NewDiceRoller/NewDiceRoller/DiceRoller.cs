﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewDiceRoller
{
    static class DiceRoller
    {

        public static void RunApp()
        {

            //  DiceCollection diceList = new DiceCollection();
            var rand = new Random();


            //var NestedListDice = new List<List<IDice>>();
            //NestedListDice.Add(new List<Dice4>().ToList<IDice>());


           

            Console.WriteLine("Welcome to the Dice Roller, Console Edition!");
            Console.WriteLine("This is the console version.");

            int diceType = -10;
            while (diceType != -1)
            {
                var dictionaryDice = new Dictionary<int, List<IDice>>();
                diceType = doDiceRolling(rand, dictionaryDice, diceType);
            }
            Console.Read();
        }

        private static int doDiceRolling(Random rand, Dictionary<int, List<IDice>> dictionaryDice, int diceType)
        {
            bool validNum = false;
            bool endDiceSession = false;

            while (!endDiceSession)
            {
                bool validType = false;
                while (!validType || !validNum)
                {

                    Console.WriteLine("Input 4, 6, 8, 10, 12, 20, or 100 to specify the type of dice you need. " +
                        "\n Input 0 to roll selected Dice" + 
                        "\n Input -1 to End Program" + 
                    "\n Inputing the same type of dice twice will overwrite the previous selection." +
                    "\n a second prompt will ask you for how many of that dice you need.");
                    validType = int.TryParse(Console.ReadLine(), out diceType);
                    validNum = checkDiceTypeValue(diceType);
                }
                
                

                //Gets the number of dice Needed; rolls all selected dice if input is 0
                if (diceType != 0 && diceType != -1)
                {
                    getNumOfDice(rand, dictionaryDice, diceType);
                }
                else if (diceType != -1)
                {
                    RollAllDice(rand, dictionaryDice);
                    endDiceSession = true;
                }
                else
                {
                    endDiceSession = true;
                }
            }
            return diceType;
        }

        private static void RollAllDice(Random rand, Dictionary<int, List<IDice>> dictionaryDice)
        {
            Console.Write("\n\n");
            foreach (int item in dictionaryDice.Keys)
            {
                Console.Write("D" + item + " Rolls: ");
                foreach (IDice dice in dictionaryDice[item])
                {
                    Console.Write(dice.RollDice(rand) + "; ");
                }
                Console.Write("\n");
            }
            Console.Write("\n\n");
        }

        private static void getNumOfDice(Random rand, Dictionary<int, List<IDice>> dictionaryDice, int diceType)
        {
            bool greaterThanZero = false;
            bool validInt = false;
            int diceNum = 0;

            while (!validInt || !greaterThanZero)
            { 
                
                Console.WriteLine("How many D" + diceType + "s do you need?");
                validInt = int.TryParse(Console.ReadLine(), out diceNum);
                if(diceNum > 0)
                {
                    greaterThanZero = true;
                }
            }

            if (dictionaryDice.ContainsKey(diceType))
            {
                dictionaryDice[diceType] = DiceFactory.GetDice(diceType, diceNum);
            }
            else
            {
                dictionaryDice.Add(diceType, DiceFactory.GetDice(diceType, diceNum));
            }



        }

        private static bool checkDiceTypeValue(int diceType)
        {
            if (diceType == 4 || diceType == 6 || diceType == 8 || diceType == 10 || diceType == 12 || diceType == 20 || diceType == 100 || diceType == 0 || diceType == -1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
