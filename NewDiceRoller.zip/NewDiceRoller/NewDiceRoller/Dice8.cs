﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewDiceRoller
{
    class Dice8: AbsDice
    {
        protected override void GetSides() => Sides = 8;
    }
}
