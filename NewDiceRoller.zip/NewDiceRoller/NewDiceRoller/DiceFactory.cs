﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewDiceRoller
{
    static class DiceFactory
    {

        public static List<IDice> GetDice(int sides, int dices)
        {
            List<IDice> diceList;
            switch (sides)
            {
                case 4:
                    diceList = new List<Dice4>().ToList<IDice>();
                    for (int i = 0; i < dices; i++)
                    {
                        diceList.Add(new Dice4());
                    }
                    break;
                case 6:
                    diceList = new List<Dice6>().ToList<IDice>();
                    for (int i = 0; i < dices; i++)
                    {
                        diceList.Add(new Dice6());
                    }
                    break;
                case 8:
                    diceList = new List<Dice8>().ToList<IDice>();
                    for (int i = 0; i < dices; i++)
                    {
                        diceList.Add(new Dice8());
                    }
                    break;
                case 10:
                    diceList = new List<Dice10>().ToList<IDice>();
                    for (int i = 0; i < dices; i++)
                    {
                        diceList.Add(new Dice10());
                    }
                    break;
                case 12:
                    diceList = new List<Dice12>().ToList<IDice>();
                    for (int i = 0; i < dices; i++)
                    {
                        diceList.Add(new Dice12());
                    }
                    break;
                case 20:
                    diceList = new List<Dice20>().ToList<IDice>();
                    for (int i = 0; i < dices; i++)
                    {
                        diceList.Add(new Dice20());
                    }
                    break;
                default:
                    diceList = new List<Dice100>().ToList<IDice>();
                    for (int i = 0; i < dices; i++)
                    {
                        diceList.Add(new Dice100());
                    }
                    break;
            }

            return diceList;
        }
    }
}
