﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewDiceRoller
{
    abstract class AbsDice : IDice
    {

        protected int Sides { get; set; }
        protected abstract void GetSides();
        public virtual int RollDice(Random rand)
        {
            
            GetSides();
            return rand.Next(1, Sides + 1);
        }
    }
}
