﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewDiceRoller
{
    class Dice100: Dice10
    {
        protected override void GetSides() => Sides = 10;
        public override int RollDice(Random rand)
        {
            return (base.RollDice(rand) * 10);
        }
    }
}
