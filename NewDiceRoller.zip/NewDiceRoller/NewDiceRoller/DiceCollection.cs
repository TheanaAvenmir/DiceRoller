﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewDiceRoller
{
    class DiceCollection
    {
        public List<Dice4> Dice4s  { get; set; }
        public List<Dice6> Dice6s { get; set; }
        public List<Dice8> Dice8s { get; set; }
        public List<Dice10> Dice10s { get; set; }
        public List<Dice12> Dice12s { get; set; }
        public List<Dice20> Dice20s { get; set; }
        public List<Dice100> Dice100s { get; set; }
       
    }
}
